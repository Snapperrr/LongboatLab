scoreboard players set @s lr_cp 50
title @s actionbar {"text":"盘山水路 33","color":"aqua","bold":false}
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 1.2
