scoreboard players set @s lr_cp 20
title @s actionbar {"text":"曲水连弯 1","color":"aqua","bold":false}
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 1.2
