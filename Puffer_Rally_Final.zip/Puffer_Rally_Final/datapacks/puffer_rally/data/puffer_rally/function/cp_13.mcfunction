scoreboard players set @s lr_cp 13
title @s actionbar {"text":"13 检查点","color":"aqua","bold":false}
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 1.2
