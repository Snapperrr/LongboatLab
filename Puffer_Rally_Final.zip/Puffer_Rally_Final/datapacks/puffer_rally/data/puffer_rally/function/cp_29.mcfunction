scoreboard players set @s lr_cp 29
title @s actionbar {"text":"曲水连弯 10","color":"aqua","bold":false}
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 1.2
